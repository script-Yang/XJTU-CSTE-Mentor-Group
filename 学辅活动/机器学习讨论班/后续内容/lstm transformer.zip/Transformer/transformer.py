import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import copy
from torch.autograd import Variable


class Embeddings(nn.Module):
    """
    词嵌入层,将高维one-hot矩阵变换成低维词向量
    ebd_dim: 词向量维度
    vocab: 词汇表大小
    """

    def __init__(self, ebd_dim, vocab):
        super(Embeddings, self).__init__()
        self.embed = nn.Embedding(vocab, ebd_dim)
        self.ebd_dim = ebd_dim

    def forward(self, X):
        # X: (batch_size, seq_length, vocab)
        return self.embed(X)


class PositionalEncoding(nn.Module):
    """
    位置编码层
    ebd_dim:词向量维度
    dropout:就是dropout大小
    max_len:位置编码的最大长度
    """

    def __init__(self, ebd_dim, dropout=0.0, max_len=1000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(dropout)
        pe = torch.zeros(max_len, ebd_dim)
        position = torch.arange(0, max_len).unsqueeze(1)
        feature = torch.pow(10000, torch.arange(0, ebd_dim, 2) / ebd_dim)
        pe[:, 0::2] = torch.sin(position * feature)
        pe[:, 1::2] = torch.cos(position * feature)
        pe = pe.unsqueeze(0)  # 加一层的目的是batch_size
        self.register_buffer('pe', pe)

    def forward(self, X):
        # X: (batch_size, seq_length, ebd_dim)
        X = X + Variable(self.pe[:, :X.size(1)], requires_grad=False)
        return self.dropout(X)


class MultiHeadedAttention(nn.Module):
    """
    多头自注意力
    """

    def __init__(self, head, ebd_dim, dropout=0.0):
        super(MultiHeadedAttention, self).__init__()
        assert ebd_dim % head == 0
        self.feature_per_head = ebd_dim // head
        self.head = head
        self.W_q = nn.Linear(ebd_dim, ebd_dim)
        self.W_k = nn.Linear(ebd_dim, ebd_dim)
        self.W_v = nn.Linear(ebd_dim, ebd_dim)
        self.W_o = nn.Linear(ebd_dim, ebd_dim)
        self.dropout = nn.Dropout(dropout) if dropout else None

    def forward(self, query, key, value, mask=None):
        # 如果是自注意力的话query:(batch_size, seq_length, ebd_dim)
        # 多头变成(batch_size, head, seq_length, feature_per_head)
        if mask is not None:
            mask = mask.unsqueeze(1)
        batch_size = query.size(0)
        query = self.W_q(query).view(batch_size, -1, self.head, self.feature_per_head).permute(0, 2, 1, 3)
        key = self.W_k(key).view(batch_size, -1, self.head, self.feature_per_head).permute(0, 2, 1, 3)
        value = self.W_v(value).view(batch_size, -1, self.head, self.feature_per_head).permute(0, 2, 1, 3)

        scores = torch.matmul(query, key.permute(0, 1, 3, 2)) / self.feature_per_head ** .5
        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)
        attention = F.softmax(scores, dim=-1)  # 对同一个query的特征取softmax
        if self.dropout:
            attention = self.dropout(attention)
        output = torch.matmul(attention, value).permute(0, 2, 1, 3).reshape(batch_size, -1,
                                                                            self.head * self.feature_per_head)
        return self.W_o(output)


class AddNormLayer(nn.Module):
    """
    残差连接+layer norm
    """

    def __init__(self, ebd_dim, dropout=0.0):
        super(AddNormLayer, self).__init__()
        self.norm = nn.LayerNorm(ebd_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, X, Y):
        # X:原始数据
        # Y: 残差
        # 先norm后dropout是希望为了保留残差这一概念
        return X + self.dropout(self.norm(Y))


class PositionWiseFeedForward(nn.Module):
    """
    ffn,最后的前馈层
    """

    def __init__(self, ebd_dim, hidden, dropout=0.0):
        super(PositionWiseFeedForward, self).__init__()
        self.func = nn.Sequential(
            nn.Linear(ebd_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, ebd_dim),
            nn.Dropout(dropout))

    def forward(self, X):
        return self.func(X)


def clone(module, N):
    return nn.ModuleList([copy.deepcopy(module) for _ in range(N)])


def subsequent_mask(seq_len):
    """
    用于构造下三角mask,主要给tgt_mask,即生成时词的后者无法影响前者
    np.triu:将矩阵变成上三角,即去掉第k对角线下面的所有元素
    """
    attn_shape = (1, seq_len, seq_len)
    mask = np.triu(np.ones(attn_shape), k=1).astype('uint8')
    return torch.from_numpy(mask) == 0


class EncodeLayer(nn.Module):
    """
    编码器层,把之前的组件拼装好
    显然,对于一个需要多次使用的Encoder,输入和输出大小需要完全一致
    """

    def __init__(self, ebd_dim, attention, ffn, dropout=0.0):
        super(EncodeLayer, self).__init__()
        self.attention_layer = attention
        self.ffn = ffn
        self.add_norm = clone(AddNormLayer(ebd_dim, dropout), 2)
        self.ebd_dim = ebd_dim

    def forward(self, X, mask=None):
        # X:(batch_size, seq_length, ebd_dim)
        # mask:(batch_size, seq_length, seq_length)
        X = self.add_norm[0](X, self.attention_layer(X, X, X, mask))
        return self.add_norm[1](X, self.ffn(X))


class Encoder(nn.Module):
    """
    将多个编码层组合形成的编码器
    """

    def __init__(self, encoder_layer, N):
        super(Encoder, self).__init__()
        self.layers = clone(encoder_layer, N)
        self.norm = nn.LayerNorm(encoder_layer.ebd_dim)

    def forward(self, X, mask=None):
        for layer in self.layers:
            X = layer(X, mask)
        return self.norm(X)


class DecoderLayer(nn.Module):
    """
    解码器层,值得注意的是其第二个注意力层需要用编码器的输出当key和value,自己提供query
    src: source,表示encoder输出需要的mask
    tgt: target,表示decoder输入需要的mask
    """

    def __init__(self, ebd_dim, self_attn, src_attn, ffn, dropout=0.0):
        super(DecoderLayer, self).__init__()
        self.first_attn = self_attn
        self.sec_attn = src_attn
        self.ffn = ffn
        self.add_norm = clone(AddNormLayer(ebd_dim, dropout), 3)
        self.ebd_dim = ebd_dim

    def forward(self, X, memory, src_mask=None, tgt_mask=None):
        X = self.add_norm[0](X, self.first_attn(X, X, X, tgt_mask))
        X = self.add_norm[1](X, self.sec_attn(X, memory, memory, src_mask))
        return self.add_norm[2](X, self.ffn(X))


class Decoder(nn.Module):
    """
    将多个解码层组合形成的解码器,注意它们用的memory都是从编码器最顶层输出的
    """

    def __init__(self, decoder_layer, N):
        super(Decoder, self).__init__()
        self.layers = clone(decoder_layer, N)
        self.norm = nn.LayerNorm(decoder_layer.ebd_dim)

    def forward(self, X, memory, src_mask=None, tgt_mask=None):
        for layer in self.layers:
            X = layer(X, memory, src_mask, tgt_mask)
        return self.norm(X)


class Generator(nn.Module):
    """
    Decoder之后的全连接层进行词预测
    """

    def __init__(self, ebd_dim, vocab):
        super(Generator, self).__init__()
        self.proj = nn.Linear(ebd_dim, vocab)

    def forward(self, X):
        # X:(batch.size, seq_length, ebd_dim), proj操作后变成(batch.size, seq_length, vocab)
        # log_softmax就是softmax后面接一层log,得到对数概率,因为使用KL散度当loss function,故手动softmax,使用交叉熵则不需要
        return F.log_softmax(self.proj(X), dim=-1)


class EncoderDecoder(nn.Module):
    """
    前面所有的层合在一起,包括词嵌入层
    """

    def __init__(self, encoder, decoder, src_embed, tgt_embed, generator):
        super(EncoderDecoder, self).__init__()
        self.encoder = encoder
        self.decoder = decoder
        self.generator = generator
        self.src_embed = src_embed
        self.tgt_embed = tgt_embed

    def encode(self, src, src_mask=None, ):
        return self.encoder(self.src_embed(src), src_mask)

    def decode(self, memory, tgt, src_mask=None, tgt_mask=None):
        return self.decoder(self.tgt_embed(tgt), memory, src_mask, tgt_mask)

    def forward(self, src, tgt, src_mask=None, tgt_mask=None):
        memory = self.encoder(self.src_embed(src), src_mask)
        return self.decoder(self.tgt_embed(tgt), memory, src_mask, tgt_mask)


def make_model(src_vocab, tgt_vocab, N=6, ebd_dim=512, hidden=2048, h=8, dropout=0.1):
    c = copy.deepcopy
    attn = MultiHeadedAttention(h, ebd_dim, dropout)
    ffn = PositionWiseFeedForward(ebd_dim, hidden, dropout)
    position = PositionalEncoding(ebd_dim, dropout)
    model = EncoderDecoder(
        Encoder(EncodeLayer(ebd_dim, c(attn), c(ffn), dropout), N),
        Decoder(DecoderLayer(ebd_dim, c(attn), c(attn), c(ffn), dropout), h),
        nn.Sequential(Embeddings(ebd_dim, src_vocab), c(position)),
        nn.Sequential(Embeddings(ebd_dim, tgt_vocab), c(position)),
        Generator(ebd_dim, tgt_vocab)
    )

    for p in model.parameters():
        if p.dim() > 1:
            nn.init.kaiming_normal_(p)
    return model


class Batch:
    """
    为每个batch对象生成mask
    src: 以下标形式存储的文本:(batch_size, seq_len)
    pad:为每个句子填充的最大长度,用<pad>填充,故为1
    """

    def __init__(self, src, tgt=None, pad=1):
        self.src = src
        self.src_mask = (src != pad).unsqueeze(-2)

        if tgt is not None:
            self.tgt = tgt[:, :-1]
            self.tgt_y = tgt[:, 1:]
            # 即对于训练来说,我们输入tgt和src,希望它输出tgt_y
            self.tgt_mask = self.make_std_mask(self.tgt, pad)
            self.tokens = torch.sum((self.tgt_y != pad))

    @staticmethod
    def make_std_mask(tgt, pad):
        tgt_mask = (tgt != pad).unsqueeze(-2)
        tgt_mask = tgt_mask & subsequent_mask(tgt.size(-1))
        # 即一个词想要被注意,必须满足在当前词之前,且不能是<pad>
        return tgt_mask


class NoamOptimizer:
    """
    Transformer 需要Warmup,否则太难收敛了
    """

    def __init__(self, model_size, factor, warmup, optimizer):
        self.optimizer = optimizer
        self._step = 0
        self.warmup = warmup
        self.factor = factor
        self.model_size = model_size
        self._rate = 0

    def step(self):
        self._step += 1
        rate = self.rate()
        for p in self.optimizer.param_groups:
            p['lr'] = rate
        self._rate = rate
        self.optimizer.step()

    def rate(self, step=None):
        if step is None:
            step = self._step
        return self.factor * (self.model_size ** (-.5) * min(step ** (-.5), step * self.warmup ** (-1.5)))


class LabelSmoothing(nn.Module):
    """
    损失函数层,将原本的softmax再smooth一下,让语言尽可能产生一点多样性,而不是完全one-hot
    """

    def __init__(self, vocab_size, pad_idx=1, smoothing=0.0):
        super(LabelSmoothing, self).__init__()
        self.criterion = nn.KLDivLoss(reduction='sum')
        self.pad_idx = pad_idx
        self.confidence = 1 - smoothing  # confidence表示将最大值缩放到某个系数
        self.smoothing = smoothing
        self.vocab_size = vocab_size
        self.true_dist = None

    def forward(self, X, target):
        # X:(batch_size*seq_len, vocab_size), target 只有X的第一维
        assert X.size(1) == self.vocab_size
        # 去掉一个<pad>和一个confidence最大值,故减2
        true_dist = torch.ones_like(X) * (self.smoothing / (self.vocab_size - 2))
        true_dist[range(X.size(0)), target.data] = self.confidence
        true_dist[:, self.pad_idx] = 0
        # 如果target内有<pad>,则需要将对应的概率一齐清空
        mask = torch.nonzero(target.data == self.pad_idx)
        if mask.dim() > 0:
            true_dist.index_fill_(0, mask.squeeze(), 0.0)
        self.true_dist = true_dist
        return self.criterion(X, Variable(true_dist, requires_grad=False))


class LossCompute:
    """
    将Loss function与Generator结合
    同时帮助直接进行反向传播,直接代替optimizer
    """

    def __init__(self, generator, criterion, opt=None):
        self.generator = generator
        self.criterion = criterion
        self.opt = opt
        self.iters = 0

    def __call__(self, X, y, norm, model):
        # norm为y中非<pad>的token个数,即有效长度
        X = self.generator(X)
        loss = self.criterion(X.contiguous().view(-1, X.size(-1)), y.contiguous().view(-1)) / norm.item()
        loss.backward()
        if self.opt:
            self.opt.step()
            self.opt.optimizer.zero_grad()
        return loss.data.item() * norm.item()

    def lr_decay(self, decay=0.95):
        self.opt.param_groups[0]['lr'] *= decay

if __name__ == '__main__':
    tmp_model = make_model(10, 10, 2)
    for name, param in tmp_model.named_parameters():
        if param.requires_grad:
            print(name, param.data.shape)
        else:
            print('no gradient necessary', name, param.data.shape)

