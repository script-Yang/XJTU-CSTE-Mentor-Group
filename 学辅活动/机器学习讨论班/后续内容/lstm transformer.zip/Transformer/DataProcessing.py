import torch
import re,copy,random
import collections
from transformer import Batch


def read_lyrics():
    with open('./data/JayLyrics.txt', 'r', encoding='utf-8') as f:
        lines = f.readlines()
    return [list(line.strip()) for line in lines]


def read_hlm():
    with open('./data/hlm.txt', 'r', encoding='utf-8') as f:
        lines = f.readlines()
    return [list(re.sub(r'[^\u4e00-\u9fff ]', '', line)) for line in lines]


class Vocab:
    """
    词汇表类,用于将词元与索引一一配对,同时过滤掉不常用词元
    reserved_tokens: 用于补充之前的可能已经有的vocab
    """

    def __init__(self, tokens, min_freq=2, reserved_tokens=None):
        if not reserved_tokens:
            reserved_tokens = ['<unk>', '<pad>', '<bos>']
        counter = Vocab.count_corpus(tokens)
        self.token_freq = sorted(counter.items(), key=lambda x: x[1], reverse=True)
        # 更新词汇表,并建立index与token的映射关系
        self.idx_to_token = reserved_tokens
        self.token_to_idx = {token: idx for idx, token in enumerate(self.idx_to_token)}
        for token, freq in self.token_freq:
            if freq < min_freq:
                break
            if token not in self.token_to_idx:
                self.idx_to_token.append(token)
                self.token_to_idx[token] = len(self.idx_to_token) - 1

    def __len__(self):
        return len(self.idx_to_token)

    def __getitem__(self, item):
        if not isinstance(item, (list, tuple)):
            return self.token_to_idx.get(item, 0)
        return [self.token_to_idx.get(token, 0) for token in item]

    def to_tokens(self, indices):
        if not isinstance(indices, (list, tuple)):
            return self.idx_to_token[indices]
        return [self.idx_to_token[idx] for idx in indices]

    @staticmethod
    def count_corpus(tokens):
        tokens = [token for line in tokens for token in line]
        return collections.Counter(tokens)


def truncate_pad(line, max_len, pad_index=1):
    if len(line) == max_len:
        return torch.tensor(line)
    elif len(line) > max_len:
        return torch.tensor(line)[:max_len]
    else:
        padding = torch.ones(max_len - len(line)) * pad_index
        return torch.cat((torch.tensor(line), padding)).type(torch.int64)


def DownSample(data, vocab):
    sentence = [[token for token in line if vocab[token]] for line in data]
    counter = vocab.count_corpus(sentence)
    num_tokens = sum(counter.values())

    def keep(token):
        return random.uniform(0, 1) < (1e-3 / counter[token] * num_tokens) ** .5

    return [[token for token in line if keep(token)] for line in sentence]


class DataLoader_lyrics:
    def __init__(self, batch_size, data, vocabulary, max_seq_len=60):
        self.data = []
        self.vocab = vocabulary
        self.batch_size = batch_size
        self.max_seq_len = max_seq_len
        for line in data:
            self.data.append(vocabulary[line])

    def random_data(self):
        num_batch = len(self.data) // self.batch_size + (len(self.data) % self.batch_size != 0)
        for i in range(0, self.batch_size * num_batch, self.batch_size):
            batch_size = min(self.batch_size, len(self.data) - i)
            X = torch.zeros((batch_size, self.max_seq_len))
            for j in range(batch_size):
                # self.data[i+j].append(3) 先不要<eos>了
                X[j] = truncate_pad(self.data[i + j], self.max_seq_len)
            X = X.long()
            yield Batch(X, copy.deepcopy(X))

    def __iter__(self):
        return self.random_data()


class Dataloader_hlm:
    def __init__(self, batch_size, data, vocabulary, max_seq_len=60):
        self.vocab = vocabulary
        self.data = [vocabulary[char] for line in data for char in line]
        self.batch_size = batch_size
        self.max_seq_len = max_seq_len

    def hlm_loader(self):
        num_seq = (len(self.data) - 1) // self.max_seq_len
        indices = list(range(0, num_seq * self.max_seq_len, self.max_seq_len))
        random.shuffle(indices)
        num_batch = num_seq // self.batch_size
        for i in range(0, self.batch_size * num_batch, self.batch_size):
            X_indices = indices[i:i + self.batch_size]
            X = [self.data[j:j + self.max_seq_len] for j in X_indices]
            X = torch.tensor(X).long()
            yield Batch(X, copy.deepcopy(X))

    def __iter__(self):
        return self.hlm_loader()


if __name__ == '__main__':
    data = read_hlm()
    vocab = Vocab(data)
