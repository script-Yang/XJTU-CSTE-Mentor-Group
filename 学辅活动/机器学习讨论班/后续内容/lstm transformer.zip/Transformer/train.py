from transformer import *
from DataProcessing import *
import time


def train_per_epoch(data_iter, model, loss_compute, print_every,device):
    st = time.time()
    total_tokens = tokens = 0
    total_loss = total_time = 0.0
    for i,batch in enumerate(data_iter):
        output = model.forward(batch.src.to(device), batch.tgt.to(device),
                               batch.src_mask.to(device), batch.tgt_mask.to(device))

        loss = loss_compute(output, batch.tgt_y.to(device), batch.tokens,model)
        total_loss += loss
        total_tokens += batch.tokens
        tokens += batch.tokens
        if (i+1) % print_every == 0:
            elapsed = time.time() - st
            print("Epoch Step: %d Loss: %.3f Speed : %f tokens/ s" %(i, loss / batch.tokens, tokens / elapsed))
            total_time += elapsed
            st = time.time()
            tokens = 0
    return total_loss / total_tokens, total_time


def train(epochs, data_iter, model, loss_compute, print_every=200,device='cuda',vocab = None):
    print(f'start training on {device}')
    tot_time = 0.0
    for e in range(epochs):
        model.train()
        loss, elapsed = train_per_epoch(data_iter, model, loss_compute,print_every,device)
        tot_time += elapsed
        if vocab and e%5 == 1:
            print('epoch: %d, time: %.3f' % (e + 1, tot_time))
            output = predict(model, "亲爱的 爱上你", vocab, device=device)
            print(''.join(output))


def predict(model, src, vocabulary, max_len=25, device='cuda'):
    # 输入一行字符串开始输出
    model.eval()
    # src_token = vocabulary[list(src)] + [3]
    src_token = vocabulary[list(src)]
    src_token = truncate_pad(src_token, max_len).unsqueeze(0).to(device)
    src_mask = (src_token != 1).unsqueeze(-2)
    memory = model.encode(src_token,src_mask)
    output = torch.ones(1,1).fill_(2).type_as(src_token.data)
    for _ in range(max_len-1):
        out = model.decode(memory, output, src_mask, subsequent_mask(output.size(1)).type_as(src_token.data))
        prob = model.generator(out[:, -1])
        next_word = torch.argmax(prob, dim=1)
        output = torch.cat([output, torch.ones(1, 1).type_as(src_token.data) * next_word], dim=1)
    return vocabulary.to_tokens(output.squeeze().tolist())