from train import *

if __name__ == '__main__':
    data = read_hlm()
    vocab = Vocab(data)
    data = DownSample(data, vocab)
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = make_model(len(vocab), len(vocab), N=1, ebd_dim=256, hidden=512, h=1, dropout=0.1)
    model.to(device)
    batch_size = 128
    lr = 5e-3
    wd = 1e-3
    opt = torch.optim.Adam(params=model.parameters(), lr=lr, weight_decay=wd)
    optimizer = NoamOptimizer(512, 2, 2000, opt)
    train_iter = Dataloader_hlm(batch_size, data, vocab, max_seq_len=50)
    criterion = LabelSmoothing(len(vocab), smoothing=0.05)
    loss_function = LossCompute(model.generator, criterion, optimizer)
    train(10, train_iter, model, loss_function, print_every=100, device=device, vocab=vocab)