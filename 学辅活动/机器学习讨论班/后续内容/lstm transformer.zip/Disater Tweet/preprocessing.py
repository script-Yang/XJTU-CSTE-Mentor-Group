import torch.nn as nn
import torch
import pandas as pd
import re
import collections

def read_data():
    # 读入数据,处理NaN
    train_df = pd.read_csv('./train.csv')
    test_df = pd.read_csv('./test.csv')
    train_df.fillna('', inplace=True)
    test_df.fillna('', inplace=True)
    return train_df, test_df


def tokenize(data):
    # 词元化
    if not isinstance(data, (tuple,list)):
        data = [data]
    content = pd.Series(dtype='object')
    for d in data:
        content = pd.concat([content,d['keyword'] +' '+ d['location'] +' '+ d['text']])
    content = content.apply(lambda x: re.sub(r'[^a-zA-Z_ ]', ' ', x).strip().lower())
    return [c.split() for c in content]


class Vocab:
    """
    词汇表类,用于将词元与索引一一配对,同时过滤掉不常用词元
    reserved_tokens: 用于补充之前的可能已经有的vocab
    """
    def __init__(self, tokens, min_freq=2, reserved_tokens=None):
        if not reserved_tokens:
            reserved_tokens = []
        counter = Vocab.count_corpus(tokens)
        self.token_freq = sorted(counter.items(),key=lambda x:x[1],reverse=True)
        # 更新词汇表,并建立index与token的映射关系
        self.idx_to_token = ['<unk>','<pad>'] + reserved_tokens
        self.token_to_idx =  {token:idx for idx,token in enumerate(self.idx_to_token)}
        for token, freq in self.token_freq:
            if freq < min_freq:
                break
            if token not in self.token_to_idx:
                self.idx_to_token.append(token)
                self.token_to_idx[token] = len(self.idx_to_token) - 1

    def __len__(self):
        return len(self.idx_to_token)

    def __getitem__(self, item):
        if not isinstance(item,(list,tuple)):
            return self.token_to_idx.get(item,0)
        return [self.token_to_idx.get(token,0) for token in item]

    def to_tokens(self, indices):
        if not isinstance(indices,(list,tuple)):
            return self.idx_to_token[indices]
        return [self.idx_to_token[idx] for idx in indices]
    @staticmethod
    def count_corpus(tokens):
        tokens = [token for line in tokens for token in line]
        return collections.Counter(tokens)

class DataLoader:
    def __init__(self, batch_size, data_df, vocabulary, max_seq_len=60,train=False):
        if train:
            df = data_df.sample(frac=1, random_state=123)
        else:
            df = data_df

        content = df['keyword'] +' '+ df['location'] +' '+ df['text']
        content = content.apply(lambda x: re.sub(r'[^a-zA-Z_ ]', ' ', x).strip().lower())
        self.data = content
        self.label = df['target'] if train else None
        self.vocab = vocabulary
        self.batch_size = batch_size
        self.max_seq_len = max_seq_len
        self.train = train

    def random_data(self,train=False):
        num_batch = len(self.data)//self.batch_size + (len(self.data)%self.batch_size != 0)
        for i in range(0,self.batch_size*num_batch, self.batch_size):
            X = self.data[i:i+self.batch_size]
            X = X.apply(lambda x:torch.Tensor(self.vocab[x.split()][:self.max_seq_len])).tolist()
            X.append(torch.zeros(self.max_seq_len))
            X = nn.utils.rnn.pad_sequence(X,batch_first=True,padding_value=1)[:-1]
            if train:
                yield X.type(torch.int64),torch.tensor(self.label[i:i+self.batch_size].tolist())
            else:
                yield X.type(torch.int64)

    def __iter__(self):
        return self.random_data(self.train)


if __name__ == '__main__':
    tokens = tokenize(read_data())
    vocab = Vocab(tokens)