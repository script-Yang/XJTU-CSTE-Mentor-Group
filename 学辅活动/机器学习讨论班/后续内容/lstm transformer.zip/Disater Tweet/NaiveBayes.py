from preprocessing import *
from sklearn.model_selection import train_test_split
from sklearn import naive_bayes as nb
from sklearn.metrics import accuracy_score,classification_report,confusion_matrix
import pandas as pd
import numpy as np


if __name__ == '__main__':
    train_df, test_df = read_data()
    tokens = tokenize((train_df, test_df))
    vocab = Vocab(tokens)
    train_content = train_df['keyword'] +' '+ train_df['location'] +' '+ train_df['text']
    train_content = train_content.apply(lambda x: re.sub(r'[^a-zA-Z_ ]', ' ', x).strip().lower())
    test_content = test_df['keyword'] +' '+ test_df['location'] +' '+ test_df['text']
    test_content = test_content.apply(lambda x: re.sub(r'[^a-zA-Z_ ]', ' ', x).strip().lower())
    train_data = np.zeros((len(train_content), len(vocab)))
    train_label = train_df['target'].to_numpy()
    test_data = np.zeros((len(test_content), len(vocab)))
    for i,sen in enumerate(train_content):
        for j in vocab[sen.split()]:
            train_data[i,j] += 1
    for i,sen in enumerate(test_content):
        for j in vocab[sen.split()]:
            test_data[i,j] += 1

    train_X,val_X,train_y,val_y = train_test_split(train_data,train_label,test_size=0.2,random_state=123)
    clf = nb.GaussianNB()
    clf.fit(train_data,train_label)
    predicted_label = clf.predict(test_data)
    submission = pd.DataFrame({'id':test_df['id'], 'target':predicted_label})
    submission.to_csv('./submission.csv',encoding='utf-8',index=False)
    print('Done!')
    # print("train score:", clf.score(train_X, train_y))
    # print("test score:", clf.score(val_X, val_y))
    # print("Classifier Accuracy:", accuracy_score(val_y, predicted_label))
    # print("Classifier Report:\n", classification_report(val_y, predicted_label))
    # print("Confusion Matrix:\n", confusion_matrix(val_y, predicted_label))