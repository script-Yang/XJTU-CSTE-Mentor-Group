import torch,time
import torch.nn as nn
import pandas as pd
from preprocessing import *


class LSTM(nn.Module):
    def __init__(self,ebd_dim, vocab, hidden,bidirectional=True):
        super().__init__()
        self.embed = nn.Embedding(vocab, ebd_dim)
        self.bi = 2 if bidirectional else 1
        self.rnn = nn.LSTM(ebd_dim,hidden,2,bidirectional=bidirectional)
        self.ffn = nn.Sequential(
            nn.LayerNorm(hidden*self.bi),
            #nn.Linear(hidden*self.bi,hidden*self.bi),nn.ReLU(),
            nn.Linear(hidden*self.bi,2)
        )

    def forward(self, X):
        X = self.embed(X)
        X, (ht,ct) = self.rnn(X)
        batch_size,seq_len,hidden_size = X.shape
        output = nn.functional.avg_pool1d(X.permute(0,2,1),seq_len).squeeze()
        output = self.ffn(output)
        return output, (ht,ct)

    def begin_state(self,batch_size,device):
        return (
            # 2: bidirectional, 3:num_layers
            torch.zeros((2 * 3, batch_size,self.hidden),device=device),
            torch.zeros((2 * 3, batch_size, self.hidden), device=device)
        )


def evaluate(y_hat,y):
    right = torch.sum((torch.argmax(y_hat,dim=1) == y))
    return right


def train_per_epoch(model, train_iter, loss, optimizer, device):
    # state = None
    right = tot = avg_loss = 0
    for X,y in train_iter:
        # if state is None:
        #     state = model.begin_state(X.shape[0],device)
        #     for s in state:
        #         s.detach_() # 初始状态不需更新,从计算图分离
        X,y = X.to(device),y.to(device)
        y_hat,_ = model(X)
        l = loss(y_hat, y)
        optimizer.zero_grad()
        l.backward()

        optimizer.step()
        with torch.no_grad():
            right += evaluate(y_hat,y.long())
            tot += y.numel()
            avg_loss += l
    return avg_loss/tot, right/tot


def train(model, epochs, train_iter, val_iter, loss, optimizer, device):
    print(f'train on {device}')
    st = time.time()
    for e in range(epochs):
        right = tot = avg_loss = val_loss = val_acc = 0
        train_loss, train_acc = train_per_epoch(model, train_iter, loss, optimizer, device)
        with torch.no_grad():
            for X, y in val_iter:
                X, y = X.to(device), y.to(device)
                y_hat, _ = model(X)
                l = loss(y_hat, y)
                right += evaluate(y_hat, y.long())
                tot += y.numel()
                avg_loss += l
            val_loss,val_acc = avg_loss/tot, right/tot
        print("epoch %d, time: %.3fs, train_loss: %.3f, train_acc: %.3f%%, val_loss: %.3f, val_acc: %.3f%%"
              %(e+1, time.time()-st, train_loss, train_acc*100, val_loss, val_acc*100))
    print('Finish in %.3fs'%(time.time()-st))

def predict(model,test_iter,device):
    ans = torch.zeros(1)
    with torch.no_grad():
        for X in test_iter:
            X = X.to(device)
            y_hat, _ = model(X)
            tgt = torch.argmax(y_hat,dim=1).to('cpu')
            ans = torch.concat([ans,tgt])
    return ans[1:].type(torch.int64)

def save_result(test_df, result):
    submission = pd.DataFrame({'id':test_df['id'], 'target':result})
    submission.to_csv('./submission.csv',encoding='utf-8',index=False)
    print('Done!')



if __name__ == '__main__':
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    batch_size = 128
    train_df, test_df = read_data()
    tokens = tokenize((train_df, test_df))
    vocab = Vocab(tokens)
    train_data = train_df.sample(frac=0.8, random_state=123)
    val_data = train_df[~train_df.index.isin(train_data.index)]
    train_iter = DataLoader(batch_size,train_data,vocab,max_seq_len=20,train=True)
    val_iter = DataLoader(batch_size,val_data,vocab,max_seq_len=20,train=True)
    test_iter = DataLoader(batch_size,test_df,vocab,max_seq_len=20,train=False)

    model = LSTM(256,len(vocab),512,bidirectional=False)
    for name, param in model.named_parameters():
        if len(param.shape) > 1:
            nn.init.xavier_normal_(param,gain=1)
        else:
            nn.init.constant_(param, 0)
    model = model.to(device)
    epochs = 5
    loss = nn.CrossEntropyLoss(reduction='sum')
    optimizer = torch.optim.Adam(model.parameters(),lr=5e-3,weight_decay=1e-3)
    train(model, epochs, train_iter, val_iter, loss, optimizer, device)
    result = predict(model,test_iter,device)
    save_result(test_df, result)



